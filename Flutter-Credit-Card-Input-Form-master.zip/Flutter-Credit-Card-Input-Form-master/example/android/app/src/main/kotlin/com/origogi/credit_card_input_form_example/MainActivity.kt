package com.origogi.credit_card_input_form_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
