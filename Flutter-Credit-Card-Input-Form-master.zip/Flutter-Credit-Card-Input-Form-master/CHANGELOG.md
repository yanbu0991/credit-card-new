## 1.0.0

* First Release

## 1.0.1

* Adjust flutter format

## 1.0.2

* update lastest provider library

## 1.0.3

* update README

## 1.0.4

* update README
  - change homepage

## 1.0.5

* Fixed isssue when calling setState () with onStateChange () callback

## 1.1.0

* Add `RESET`button

## 1.1.1

* update README

## 1.2.0

* added custom captions feature

## 1.3.0

* added custom button style feature

## 1.3.1

* removed duplicated code

## 2.0.0

* added custom card boxdecoration

## 2.0.1

* fix readme

## 2.0.2

* update provider library

## 2.0.3

* If the card number is Amex, the CVC code will be 4 digits, otherwise it will be 3 digits.

## 2.0.4

* Removed unused library

## 2.0.5

* Removed debug message

## 2.1.0

* implement a new feature to add an initial value when creating a widget

## 2.1.1

* Fix readme

## 2.1.2

* Fix card number overflow in smaller devices like iPhone SE.

## 2.1.3

* Fix readme

## 2.1.4

* Fix text field bottom overflow 4 pixels in Samsung device.

## 2.1.5

* Prevents characters from being entered into the card number

## 2.1.6

* Prevents special characters from being entered into the card number

### v2.2.0

Add initial autofocus parameter

### v2.3.0

Flutter 2.0 migration